<?php
/*
Template Name: About App Template
*/

get_header();
?>

<div class="content">
    <?php
    // Include the content from about_app.html
    include locate_template('about_app.html');
    ?>
</div>

<?php
get_footer();
?>
